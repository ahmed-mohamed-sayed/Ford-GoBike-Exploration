# (Ford GoBike System Data)
## by (Ahmed Mohamed Sayed)


## Dataset

> This Data related to Ford GoBike System (public bike sharing system) for february month in year 2019.
Data covering 183411  trips occured in the San Francisco Bay Area, California During the month.

> Wrangling Steps:
-  Dropping unneeded columns.
-  Add duration minutes columnn
- converting start_time to datetime to extract star_day 0f week & start_hour
- Creating Age column
- Dropping Trips which have duration min > 100




## Summary of Findings

> Trips Starting Hours distribution is a bimodal distribution. we have two peak periods for trips.
from 6 to 9 AM and from 4 to 6 PM. Most of the trips occurred during rush hours (when going or back from work).In other words, Riders using the Bike Share System Mainly to go to their work.

>The Distribution of Trip Starting Day of week Confirms the previous conclusion. weekend days have the least Trips among the whole week.

>Males use Bike Share System 3 times than Females.

>87.5% of Trips occurred by Subscribers & 12.5% by Customers.

> Subscribers tend to have short & regular trips. unlike Customers who tend to take longer rides.

> User Ages are very close between Subscribers & Customers. Subscribers are older with small differences.

>average trip duration for females is higher than males. Also,
average trip duration for customers is higher than subscribers.

## Key Insights for Presentation

> Males are 3 times higher than females but have avg trip duration lower than females. Also, subscribers are representing 87.5% of the dataset but have a lower avg trip duration than the customers.